
        function showMenu() {
            document.getElementById("menu").style.zIndex = 1
        }

        function hideMenu()
        {
            document.getElementById("menu").style.zIndex = -1
            }